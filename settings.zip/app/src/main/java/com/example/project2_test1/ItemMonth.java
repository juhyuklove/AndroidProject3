package com.example.project2_test1;

public class ItemMonth {
    String nYear;
    String nMonth;
    String nDayNum; // text
    String nText1;
    String nText2;
    ItemMonth(String aYear, String aMonth, String aDayNum, String aText1, String aText2) {
        nYear = aYear;
        nMonth = aMonth;
        nDayNum = aDayNum;
        nText1 = aText1;
        nText2 = aText2;
    }
}